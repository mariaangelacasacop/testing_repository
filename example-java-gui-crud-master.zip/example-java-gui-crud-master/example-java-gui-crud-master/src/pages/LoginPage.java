package pages;

import dal.admins.AdminDAO;

import javax.swing.*;
import java.awt.*;

public class LoginPage extends JFrame {
    private final AdminDAO adminDao = new AdminDAO();
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton signInButton;

    public LoginPage() {
        setTitle("Admin Login");
        setSize(500, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Main background panel with solid yellow
        JPanel bgPanel = new JPanel(new GridBagLayout());
        bgPanel.setBackground(new Color(255, 234, 0)); // Solid yellow
        add(bgPanel);

        // Login panel
        JPanel loginPanel = new JPanel();
        loginPanel.setPreferredSize(new Dimension(350, 220));
        loginPanel.setBackground(new Color(255, 255, 255, 220)); // Slight transparency for contrast
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel titleLabel = new JLabel("Admin Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginPanel.add(titleLabel);
        loginPanel.add(Box.createVerticalStrut(15));

        // Username
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userPanel.setOpaque(false);
        JLabel userLabel = new JLabel("Username:");
        userLabel.setPreferredSize(new Dimension(80, 25));
        usernameField = new JTextField(20);
        userPanel.add(userLabel);
        userPanel.add(usernameField);
        loginPanel.add(userPanel);

        // Password
        JPanel passPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        passPanel.setOpaque(false);
        JLabel passLabel = new JLabel("Password:");
        passLabel.setPreferredSize(new Dimension(80, 25));
        passwordField = new JPasswordField(20);
        passPanel.add(passLabel);
        passPanel.add(passwordField);
        loginPanel.add(passPanel);

        // Button
        signInButton = new JButton("Sign In");
        signInButton.setFont(new Font("Arial", Font.BOLD, 14));
        signInButton.setBackground(new Color(59, 89, 182));
        signInButton.setForeground(Color.WHITE);
        signInButton.setFocusPainted(false);
        signInButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        signInButton.addActionListener(e -> handleLogin());
        loginPanel.add(Box.createVerticalStrut(15));
        loginPanel.add(signInButton);

        bgPanel.add(loginPanel);
        setVisible(true);
    }

    private void handleLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.");
            return;
        }

        boolean valid = adminDao.checkIfAdminExists(username, password);
        if (valid) {
            JOptionPane.showMessageDialog(this, "Login successful!");
            new StudentPage();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }
    }
}
